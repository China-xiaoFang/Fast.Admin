INSERT INTO [TableConfig] ([TableId], [TableKey], [TableName], [Remark], [DepartmentId], [DepartmentName], [CreatedUserId], [CreatedUserName], [CreatedTime], [UpdatedUserId], [UpdatedUserName], [UpdatedTime], [RowVersion]) VALUES (759868433952838, N'1D11YYQH9M', N'开发应用_Api_接口管理_分页列表', NULL, NULL, NULL, NULL, N'超级管理员', '2026-01-01 00:00:00.000', NULL, NULL, NULL, 1);
GO
INSERT INTO [TableConfig] ([TableId], [TableKey], [TableName], [Remark], [DepartmentId], [DepartmentName], [CreatedUserId], [CreatedUserName], [CreatedTime], [UpdatedUserId], [UpdatedUserName], [UpdatedTime], [RowVersion]) VALUES (759868597907526, N'1D11JKRR5Q', N'开发应用_开发管理_系统配置_分页列表', NULL, NULL, NULL, NULL, N'超级管理员', '2026-01-01 00:00:00.000', NULL, NULL, NULL, 1);
GO
INSERT INTO [TableConfig] ([TableId], [TableKey], [TableName], [Remark], [DepartmentId], [DepartmentName], [CreatedUserId], [CreatedUserName], [CreatedTime], [UpdatedUserId], [UpdatedUserName], [UpdatedTime], [RowVersion]) VALUES (759868675649606, N'1D11Q5S4P2', N'开发应用_开发管理_菜单管理_分页列表', NULL, NULL, NULL, NULL, N'超级管理员', '2026-01-01 00:00:00.000', NULL, NULL, NULL, 1);
GO
INSERT INTO [TableConfig] ([TableId], [TableKey], [TableName], [Remark], [DepartmentId], [DepartmentName], [CreatedUserId], [CreatedUserName], [CreatedTime], [UpdatedUserId], [UpdatedUserName], [UpdatedTime], [RowVersion]) VALUES (759868769284166, N'1D11MFM59S', N'开发应用_开发管理_序号配置_分页列表', NULL, NULL, NULL, NULL, N'超级管理员', '2026-01-01 00:00:00.000', NULL, NULL, NULL, 1);
GO
INSERT INTO [TableConfig] ([TableId], [TableKey], [TableName], [Remark], [DepartmentId], [DepartmentName], [CreatedUserId], [CreatedUserName], [CreatedTime], [UpdatedUserId], [UpdatedUserName], [UpdatedTime], [RowVersion]) VALUES (759868769321154, N'1DFGFQQD95', N'开发应用_开发管理_密码记录_分页列表', NULL, NULL, NULL, NULL, N'超级管理员', '2026-01-01 00:00:00.000', NULL, NULL, NULL, 1);
GO
INSERT INTO [TableConfig] ([TableId], [TableKey], [TableName], [Remark], [DepartmentId], [DepartmentName], [CreatedUserId], [CreatedUserName], [CreatedTime], [UpdatedUserId], [UpdatedUserName], [UpdatedTime], [RowVersion]) VALUES (759868820312134, N'1D11ZDNHT5', N'开发应用_系统日志_异常日志_分页列表', NULL, NULL, NULL, NULL, N'超级管理员', '2026-01-01 00:00:00.000', NULL, NULL, NULL, 1);
GO
INSERT INTO [TableConfig] ([TableId], [TableKey], [TableName], [Remark], [DepartmentId], [DepartmentName], [CreatedUserId], [CreatedUserName], [CreatedTime], [UpdatedUserId], [UpdatedUserName], [UpdatedTime], [RowVersion]) VALUES (759868849938502, N'1D115PF8PK', N'开发应用_系统日志_Sql异常日志_分页列表', NULL, NULL, NULL, NULL, N'超级管理员', '2026-01-01 00:00:00.000', NULL, NULL, NULL, 1);
GO
INSERT INTO [TableConfig] ([TableId], [TableKey], [TableName], [Remark], [DepartmentId], [DepartmentName], [CreatedUserId], [CreatedUserName], [CreatedTime], [UpdatedUserId], [UpdatedUserName], [UpdatedTime], [RowVersion]) VALUES (759868875202630, N'1D11DZCT3N', N'开发应用_系统日志_Sql超时日志_分页列表', NULL, NULL, NULL, NULL, N'超级管理员', '2026-01-01 00:00:00.000', NULL, NULL, NULL, 1);
GO
INSERT INTO [TableConfig] ([TableId], [TableKey], [TableName], [Remark], [DepartmentId], [DepartmentName], [CreatedUserId], [CreatedUserName], [CreatedTime], [UpdatedUserId], [UpdatedUserName], [UpdatedTime], [RowVersion]) VALUES (759868907413574, N'1D11PB3CXH', N'开发应用_系统日志_Sql执行日志_分页列表', NULL, NULL, NULL, NULL, N'超级管理员', '2026-01-01 00:00:00.000', NULL, NULL, NULL, 1);
GO
INSERT INTO [TableConfig] ([TableId], [TableKey], [TableName], [Remark], [DepartmentId], [DepartmentName], [CreatedUserId], [CreatedUserName], [CreatedTime], [UpdatedUserId], [UpdatedUserName], [UpdatedTime], [RowVersion]) VALUES (759868934541382, N'1D11BD21TV', N'开发应用_系统日志_Sql差异日志_分页列表', NULL, NULL, NULL, NULL, N'超级管理员', '2026-01-01 00:00:00.000', NULL, NULL, NULL, 1);
GO
INSERT INTO [TableConfig] ([TableId], [TableKey], [TableName], [Remark], [DepartmentId], [DepartmentName], [CreatedUserId], [CreatedUserName], [CreatedTime], [UpdatedUserId], [UpdatedUserName], [UpdatedTime], [RowVersion]) VALUES (759869094027334, N'1D11KCYJJ9', N'系统应用_文件存储_分页列表', NULL, NULL, NULL, NULL, N'超级管理员', '2026-01-01 00:00:00.000', NULL, NULL, NULL, 1);
GO
INSERT INTO [TableConfig] ([TableId], [TableKey], [TableName], [Remark], [DepartmentId], [DepartmentName], [CreatedUserId], [CreatedUserName], [CreatedTime], [UpdatedUserId], [UpdatedUserName], [UpdatedTime], [RowVersion]) VALUES (759869184880710, N'1D1FT74TNX', N'系统应用_系统管理_租户管理_分页列表', NULL, NULL, NULL, NULL, N'超级管理员', '2026-01-01 00:00:00.000', NULL, NULL, NULL, 1);
GO
INSERT INTO [TableConfig] ([TableId], [TableKey], [TableName], [Remark], [DepartmentId], [DepartmentName], [CreatedUserId], [CreatedUserName], [CreatedTime], [UpdatedUserId], [UpdatedUserName], [UpdatedTime], [RowVersion]) VALUES (759869271343174, N'1D1F3QYJST', N'系统应用_系统管理_数据库配置_分页列表', NULL, NULL, NULL, NULL, N'超级管理员', '2026-01-01 00:00:00.000', NULL, NULL, NULL, 1);
GO
INSERT INTO [TableConfig] ([TableId], [TableKey], [TableName], [Remark], [DepartmentId], [DepartmentName], [CreatedUserId], [CreatedUserName], [CreatedTime], [UpdatedUserId], [UpdatedUserName], [UpdatedTime], [RowVersion]) VALUES (759869359636550, N'1D1F9HNVPQ', N'系统应用_系统管理_应用管理_分页列表', NULL, NULL, NULL, NULL, N'超级管理员', '2026-01-01 00:00:00.000', NULL, NULL, NULL, 1);
GO
INSERT INTO [TableConfig] ([TableId], [TableKey], [TableName], [Remark], [DepartmentId], [DepartmentName], [CreatedUserId], [CreatedUserName], [CreatedTime], [UpdatedUserId], [UpdatedUserName], [UpdatedTime], [RowVersion]) VALUES (759869386256454, N'1D1FCQZ5KT', N'系统应用_系统管理_应用标识_分页列表', NULL, NULL, NULL, NULL, N'超级管理员', '2026-01-01 00:00:00.000', NULL, NULL, NULL, 1);
GO
INSERT INTO [TableConfig] ([TableId], [TableKey], [TableName], [Remark], [DepartmentId], [DepartmentName], [CreatedUserId], [CreatedUserName], [CreatedTime], [UpdatedUserId], [UpdatedUserName], [UpdatedTime], [RowVersion]) VALUES (759869427761222, N'1D1FXFM1GH', N'系统应用_系统管理_账号管理_分页列表', NULL, NULL, NULL, NULL, N'超级管理员', '2026-01-01 00:00:00.000', NULL, NULL, NULL, 1);
GO
INSERT INTO [TableConfig] ([TableId], [TableKey], [TableName], [Remark], [DepartmentId], [DepartmentName], [CreatedUserId], [CreatedUserName], [CreatedTime], [UpdatedUserId], [UpdatedUserName], [UpdatedTime], [RowVersion]) VALUES (759869855338566, N'1D1F6WM7DG', N'系统应用_配置管理_单号配置_分页列表', NULL, NULL, NULL, NULL, N'超级管理员', '2026-01-01 00:00:00.000', NULL, NULL, NULL, 1);
GO
INSERT INTO [TableConfig] ([TableId], [TableKey], [TableName], [Remark], [DepartmentId], [DepartmentName], [CreatedUserId], [CreatedUserName], [CreatedTime], [UpdatedUserId], [UpdatedUserName], [UpdatedTime], [RowVersion]) VALUES (759870031081542, N'1D1KR8WZ6U', N'系统应用_组织架构_职位管理_分页列表', NULL, NULL, NULL, NULL, N'超级管理员', '2026-01-01 00:00:00.000', NULL, NULL, NULL, 1);
GO
INSERT INTO [TableConfig] ([TableId], [TableKey], [TableName], [Remark], [DepartmentId], [DepartmentName], [CreatedUserId], [CreatedUserName], [CreatedTime], [UpdatedUserId], [UpdatedUserName], [UpdatedTime], [RowVersion]) VALUES (759870053077062, N'1D1KRB5KK9', N'系统应用_组织架构_职级管理_分页列表', NULL, NULL, NULL, NULL, N'超级管理员', '2026-01-01 00:00:00.000', NULL, NULL, NULL, 1);
GO
INSERT INTO [TableConfig] ([TableId], [TableKey], [TableName], [Remark], [DepartmentId], [DepartmentName], [CreatedUserId], [CreatedUserName], [CreatedTime], [UpdatedUserId], [UpdatedUserName], [UpdatedTime], [RowVersion]) VALUES (759870095609925, N'1D1KG9P5FG', N'系统应用_组织架构_角色管理_分页列表', NULL, NULL, NULL, NULL, N'超级管理员', '2026-01-01 00:00:00.000', NULL, NULL, NULL, 1);
GO
INSERT INTO [TableConfig] ([TableId], [TableKey], [TableName], [Remark], [DepartmentId], [DepartmentName], [CreatedUserId], [CreatedUserName], [CreatedTime], [UpdatedUserId], [UpdatedUserName], [UpdatedTime], [RowVersion]) VALUES (759870114635846, N'1D1KGFUXKQ', N'系统应用_组织架构_部门管理_分页列表', NULL, NULL, NULL, NULL, N'超级管理员', '2026-01-01 00:00:00.000', NULL, NULL, NULL, 1);
GO
INSERT INTO [TableConfig] ([TableId], [TableKey], [TableName], [Remark], [DepartmentId], [DepartmentName], [CreatedUserId], [CreatedUserName], [CreatedTime], [UpdatedUserId], [UpdatedUserName], [UpdatedTime], [RowVersion]) VALUES (759870141927494, N'1D1KVW17SY', N'系统应用_组织架构_职员管理_分页列表', NULL, NULL, NULL, NULL, N'超级管理员', '2026-01-01 00:00:00.000', NULL, NULL, NULL, 1);
GO
INSERT INTO [TableConfig] ([TableId], [TableKey], [TableName], [Remark], [DepartmentId], [DepartmentName], [CreatedUserId], [CreatedUserName], [CreatedTime], [UpdatedUserId], [UpdatedUserName], [UpdatedTime], [RowVersion]) VALUES (759870169608262, N'1D1K3NW4XY', N'系统应用_组织架构_在线用户_分页列表', NULL, NULL, NULL, NULL, N'超级管理员', '2026-01-01 00:00:00.000', NULL, NULL, NULL, 1);
GO
INSERT INTO [TableConfig] ([TableId], [TableKey], [TableName], [Remark], [DepartmentId], [DepartmentName], [CreatedUserId], [CreatedUserName], [CreatedTime], [UpdatedUserId], [UpdatedUserName], [UpdatedTime], [RowVersion]) VALUES (759870210891846, N'1D1KYCMJCP', N'系统应用_财务管理_商户号_分页列表', NULL, NULL, NULL, NULL, N'超级管理员', '2026-01-01 00:00:00.000', NULL, NULL, NULL, 1);
GO
INSERT INTO [TableConfig] ([TableId], [TableKey], [TableName], [Remark], [DepartmentId], [DepartmentName], [CreatedUserId], [CreatedUserName], [CreatedTime], [UpdatedUserId], [UpdatedUserName], [UpdatedTime], [RowVersion]) VALUES (759870234234949, N'1D1K9GNFPT', N'系统应用_财务管理_支付记录_分页列表', NULL, NULL, NULL, NULL, N'超级管理员', '2026-01-01 00:00:00.000', NULL, NULL, NULL, 1);
GO
INSERT INTO [TableConfig] ([TableId], [TableKey], [TableName], [Remark], [DepartmentId], [DepartmentName], [CreatedUserId], [CreatedUserName], [CreatedTime], [UpdatedUserId], [UpdatedUserName], [UpdatedTime], [RowVersion]) VALUES (759870391447622, N'1D1KL4GV24', N'系统应用_平台管理_客户端用户_分页列表', NULL, NULL, NULL, NULL, N'超级管理员', '2026-01-01 00:00:00.000', NULL, NULL, NULL, 1);
GO
INSERT INTO [TableConfig] ([TableId], [TableKey], [TableName], [Remark], [DepartmentId], [DepartmentName], [CreatedUserId], [CreatedUserName], [CreatedTime], [UpdatedUserId], [UpdatedUserName], [UpdatedTime], [RowVersion]) VALUES (759870416957510, N'1D1K7QDL5Y', N'系统应用_平台管理_投诉工单_分页列表', NULL, NULL, NULL, NULL, N'超级管理员', '2026-01-01 00:00:00.000', NULL, NULL, NULL, 1);
GO
INSERT INTO [TableConfig] ([TableId], [TableKey], [TableName], [Remark], [DepartmentId], [DepartmentName], [CreatedUserId], [CreatedUserName], [CreatedTime], [UpdatedUserId], [UpdatedUserName], [UpdatedTime], [RowVersion]) VALUES (759870437167174, N'1D1KQSM6QW', N'系统应用_平台管理_用户投诉_分页列表', NULL, NULL, NULL, NULL, N'超级管理员', '2026-01-01 00:00:00.000', NULL, NULL, NULL, 1);
GO
INSERT INTO [TableConfig] ([TableId], [TableKey], [TableName], [Remark], [DepartmentId], [DepartmentName], [CreatedUserId], [CreatedUserName], [CreatedTime], [UpdatedUserId], [UpdatedUserName], [UpdatedTime], [RowVersion]) VALUES (759870478934086, N'1D1K2Z66L4', N'系统应用_日志管理_访问日志_分页列表', NULL, NULL, NULL, NULL, N'超级管理员', '2026-01-01 00:00:00.000', NULL, NULL, NULL, 1);
GO
INSERT INTO [TableConfig] ([TableId], [TableKey], [TableName], [Remark], [DepartmentId], [DepartmentName], [CreatedUserId], [CreatedUserName], [CreatedTime], [UpdatedUserId], [UpdatedUserName], [UpdatedTime], [RowVersion]) VALUES (759870502375494, N'1D1KHQS53T', N'系统应用_日志管理_操作日志_分页列表', NULL, NULL, NULL, NULL, N'超级管理员', '2026-01-01 00:00:00.000', NULL, NULL, NULL, 1);
GO
INSERT INTO [TableConfig] ([TableId], [TableKey], [TableName], [Remark], [DepartmentId], [DepartmentName], [CreatedUserId], [CreatedUserName], [CreatedTime], [UpdatedUserId], [UpdatedUserName], [UpdatedTime], [RowVersion]) VALUES (759870522822726, N'1D1KMSURSS', N'系统应用_日志管理_请求日志_分页列表', NULL, NULL, NULL, NULL, N'超级管理员', '2026-01-01 00:00:00.000', NULL, NULL, NULL, 1);
GO
INSERT INTO [TableConfig] ([TableId], [TableKey], [TableName], [Remark], [DepartmentId], [DepartmentName], [CreatedUserId], [CreatedUserName], [CreatedTime], [UpdatedUserId], [UpdatedUserName], [UpdatedTime], [RowVersion]) VALUES (768104096829510, N'FRMY6974MU', N'系统应用_财务管理_退款记录_分页列表', NULL, NULL, NULL, NULL, N'超级管理员', '2026-01-01 00:00:00.000', NULL, NULL, NULL, 1);
GO
